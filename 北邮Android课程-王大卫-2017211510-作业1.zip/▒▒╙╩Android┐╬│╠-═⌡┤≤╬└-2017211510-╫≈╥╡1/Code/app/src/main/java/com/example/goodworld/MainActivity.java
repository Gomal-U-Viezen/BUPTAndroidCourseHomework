package com.example.goodworld;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=findViewById(R.id.button);
        final TextView textView=findViewById(R.id.textView);
        CheckBox cbx = (CheckBox) findViewById(R.id.checkBox);

        cbx.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked==true) {
                    textView.setText("What a bad world!");
                    Log.d("MainActivity","bad");
                }else{
                    textView.setText("Hello world!");
                    Log.d("MainActivity","recover");
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                textView.setText("What a wonderful world!");
                Log.d("MainActivity","good");
            }
        });

        Log.d("MainActivity","hello");
    }
}
